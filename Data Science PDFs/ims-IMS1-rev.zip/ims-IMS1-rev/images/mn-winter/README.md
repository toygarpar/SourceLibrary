This photo was taken by David Diez. It is released under the same license as the textbook.
