
https://www.flickr.com/photos/gregthebusker/5653697137/

Photo by Greg Schechter
Creative Commons Attribution 2.0 license
