library(openintro)
data(COL)

png("images/variables/variables.png", 4.2, 1.5)




dev.off()

