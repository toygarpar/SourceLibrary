---
name: Suggestion
about: Make a suggestion
---

<!--
Please use this template for making a suggestion for improvement.
Please feel free to keep comments brief. We would much prefer to follow up with you for clarification than have you spend time providing in depth suggestions for topics we have decided are outside of the scope of the book or edits that we think would change the style of the substantively.
If your suggestion is for a particular chapter/section, please make sure to include that in your comments as well.

Note that this project is released with a [Contributor Code of Conduct](https://www.contributor-covenant.org/version/2/0/code_of_conduct/). By participating in this project you agree to abide by its terms.

Thank you so much for your suggestion!
-->
