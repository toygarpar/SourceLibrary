---
name: Typo
about: Report a typo
title: Typo - Chp [___], Sec [___], [__short description of typo__]
assignees: mine-cetinkaya-rundel
---

<!--
Please use this template for reporting a typo.

Note that this project is released with a [Contributor Code of Conduct](https://www.contributor-covenant.org/version/2/0/code_of_conduct/). By participating in this project you agree to abide by its terms.

Thank you so much for your comments!
-->

- Chapter number: ___

- Section number: ___

- Other location identifier, if any (e.g., figure number, table number, footnote number, etc.): ___

- Original text: ___

- Suggestion for corrected text: ___

- Justification for suggestion: ___
